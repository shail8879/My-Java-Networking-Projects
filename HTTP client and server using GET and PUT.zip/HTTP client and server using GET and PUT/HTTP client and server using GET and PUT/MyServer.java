import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.net.*;
 
public class MyServer {
	
	private static ArrayList<MyServerThread> socketRefList;
	
	static {
		socketRefList=new ArrayList<MyServerThread>();
	}
	
	public static void main(String[] args) {
		if(args.length!=1) {
			System.out.println("Invalid Port number format. Enter a number ranging from 5000 to 9999");
			return;
		}
		MyServerThread clientThread;
		ServerSocket serverSoc=null;
		Socket soc=null;
		try {
			serverSoc=new ServerSocket(Integer.parseInt(args[0]));
			closeServerSocket(serverSoc);
			System.out.println("Server started accepting connections..!");
			while(true){
				soc=serverSoc.accept();
				if(soc==null) {
					return;
				}else{
					clientThread=new MyServerThread(soc);
					socketRefList.add(clientThread);
					clientThread.start();
				}
			}
		}
		catch(Exception e) {
			e.getLocalizedMessage();
		}
	}
	
	private static void closeServerSocket(ServerSocket serverSoc) {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable()
		{
			public void run() {
				try {
					int i = 0;
					while (i<socketRefList.size()){
						socketRefList.get(i).stopResponse();
						i++;
					}
					Thread.sleep(3000);
					serverSoc.close();
				}
				catch(Exception e) {
					e.getLocalizedMessage();
				}
			}
		}));
	}
	
	public static void removeServerThread(MyServerThread thread) {
		socketRefList.remove(thread);
	}
}