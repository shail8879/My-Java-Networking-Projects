import java.io.*;
import java.net.*; 
public class MyClient {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		if(args.length!=4) {
			System.out.println("Invalid input.. Please give valid input");
			return;
		}
		Socket soc=null;
		DataInputStream dis=null;
		PrintStream PS=null;
		byte[] b=new byte[2048];
		int integer;
		String res="",filereq=null,filecontent="";
		try {
			if(args[2].equalsIgnoreCase("GET")) {
				soc=new Socket(args[0],Integer.parseInt(args[1]));
				PS=new PrintStream(soc.getOutputStream());
				filereq=args[2].toUpperCase()+" "+args[3]+" HTTP/1.1\r\nHost: "+args[0]+"\r\n";
				PS.println(filereq);
				dis=new DataInputStream(soc.getInputStream());
				while((filecontent=dis.readLine())!=null) {
					System.out.println(filecontent);
					if(filecontent.equalsIgnoreCase("</html>"))
						break;
				}
			}
			else if(args[2].equalsIgnoreCase("PUT")){
				File myFile=new File(args[3]);
				int fileLength=(int)Math.ceil((double)myFile.length()/b.length);
				if(!myFile.exists() || !myFile.isFile()) {
					System.out.println("File Not Found");
					return;
				}
				soc=new Socket(args[0],Integer.parseInt(args[1]));
				PS=new PrintStream(soc.getOutputStream());
				dis=new DataInputStream(soc.getInputStream());
				filereq=args[2].toUpperCase()+" "+args[3]+" HTTP/1.1\r\nHost: "+args[0]+"\r\n";
				PS.println(filereq);
				FileInputStream fis=new FileInputStream(args[3]);
				filecontent="";
				PS.println(fileLength);
				while((integer=fis.read(b))!=-1)
					PS.write(b,0,integer);
				fis.close();
				while((filecontent=dis.readLine())!=null)
					res+=filecontent+"\n";
				System.out.println("\n\n"+res);
			}
			else {
				System.out.println("enter PUT or GET method");
				return;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		try {
			PS.close();
			dis.close();
			soc.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}