import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.net.*;

public class MyServerThread extends Thread {
	Socket sock;
	DataInputStream input=null;
	PrintStream output=null;
	MyServerThread(Socket socket) {
		this.sock=socket;
	}
	public void stopResponse() {
		try {
			this.output.close();
			this.input.close();
			this.sock.close();
		}
		catch(Exception e) { }
	}
	@SuppressWarnings("deprecation")
	public void run() {
		String req=null,res=null;
		String content=null,nameOfTheFile=null,nameOfTheMethod=null,temp[];
		String path="Files";
		byte[] b=new byte[2048];int i;
		try {
			input=new DataInputStream(sock.getInputStream());
			req=input.readLine();input.readLine();input.readLine();
			content=req.split("\n")[0];
			temp=content.split(" ");
			nameOfTheMethod=temp[0];
			temp=temp[1].split("/");
			nameOfTheFile=temp[temp.length-1];
			File myFile=new File(path);
			if(!myFile.exists())
				myFile.mkdir();
			path=path+"/"+nameOfTheFile;
			myFile=new File(path);
			if(nameOfTheMethod.equalsIgnoreCase("GET")) {
				if(!myFile.exists())
					res="HTTP/1.1 404 Not Found\r\n";
				else {
					res="HTTP/1.1 200 OK\r\n";
					FileInputStream fis=new FileInputStream(path);
					while((i=fis.read(b))!=-1)
						res+=new String(b,0,i)+"\n";
					fis.close();
				}
			}
			else if(nameOfTheMethod.equalsIgnoreCase("PUT")) {
				myFile=new File(path);
				if(!myFile.exists())
					myFile.createNewFile();
				int length=Integer.parseInt(input.readLine());
				FileOutputStream fos=new FileOutputStream(path);
				while(length>0) {
					i=input.read(b);
					fos.write(b,0,i);
					length--;
				}
				fos.close();
				res="HTTP/1.1 200 OK File Created";
			}
			output=new PrintStream(sock.getOutputStream());
			output.println(res);
			Thread.sleep(1000);
		}
		catch(Exception e) {
			e.getLocalizedMessage();
		}
		finally {
			try {
				output.close();
				input.close();
				sock.close();
			}
			catch(Exception e) {
				e.getLocalizedMessage();
			}
		}
		MyServer.removeServerThread(this);
	}
}