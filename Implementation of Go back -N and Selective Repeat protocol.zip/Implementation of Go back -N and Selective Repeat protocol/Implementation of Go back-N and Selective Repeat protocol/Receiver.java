
 
import java.io.*;
import java.net.*;
import java.util.*;

public class Receiver
{

	public static double probOfLostACK = 0.05;

	public static void main(String args[]) throws Exception
	{
		if (args.length != 1) {
            System.out.println("Wrong input. Please give only 1 value");
            return;
        }

        int serverPortNum;

		try{
			serverPortNum = Integer.parseInt(args[0]); //Validating Port number
		} catch(Exception e){
			System.out.println("Invalid Port Number format. Please supply integer.");
			return;
		}

		DatagramSocket serverSock = new DatagramSocket(serverPortNum);
		System.out.println("Receiver is waiting for the packets..!");

		byte[] dataByte = new byte[1024];
		DatagramPacket dataPacket = new DatagramPacket(dataByte, dataByte.length);
		serverSock.receive(dataPacket);

		String packetData = new String(dataPacket.getData());

		String[] arrayInput = packetData.split(",");

		String protocolName = arrayInput[0].trim();

		int m = Integer.parseInt(arrayInput[1].trim());// m= num of bits used in sequence num
		int N = Integer.parseInt(arrayInput[2].trim()); // N= window size
		int segSize = Integer.parseInt(arrayInput[3].trim());

		// Total Sequence No's allowed
		int prevSeqNum = (int) (Math.pow(2.0, (double) m));
		System.out.println("Protocol Name:  " + protocolName);
		if (protocolName.equalsIgnoreCase("gbn")) {
			byte[] byteReceived = new byte[16 + 1 + 4 + segSize];
			BufferedWriter bufferedOutput = new BufferedWriter(new FileWriter("output.txt"));

			boolean endSegment = false;

			int waitTime = 0;

			while(!endSegment)
			{
				// Receive Packet
				DatagramPacket packetReceived = new DatagramPacket(byteReceived, byteReceived.length);
				serverSock.receive(packetReceived);
				byte[] receivedDataByte = packetReceived.getData();

				// Convert Packet data to packet object
				DataPacket packetContent = new DataPacket(receivedDataByte, packetReceived.getLength());

				if (packetContent.packetValidity()) {
					if (waitTime % prevSeqNum == packetContent.getSeqNo()) {
						System.out.println("Received Segment " + packetContent.getSeqNo() + ";");
						endSegment = packetContent.getLast();
						String text = new String(packetContent.getData());
						bufferedOutput.write(text);
						waitTime++;
					} else{
						System.out.println("Discarded " + packetContent.getSeqNo() + "; Out-of-Order Segment Received; Expecting " + waitTime % prevSeqNum);
					}
				} else{
					System.out.println("Discarded " + packetContent.getSeqNo() + "; Checksum Error;");
				}

				// Create and ACK Packet with the sequence number
				AcknowledgementDTO ackedData = new AcknowledgementDTO((waitTime - 1) % prevSeqNum);
				byte[] bytePacket = ackedData.generatePacket();

				Thread.sleep(200);

				DatagramPacket transferACK = new DatagramPacket(bytePacket, bytePacket.length, packetReceived.getAddress(), packetReceived.getPort());

				if (Math.random() > probOfLostACK) {
					serverSock.send(transferACK);
				} else{
					System.out.println("Lost ACK");
				}

				System.out.println("ACK Sent: " + ackedData.getSeqNo());
				System.out.println("");
			}

			bufferedOutput.flush();
			bufferedOutput.close();

			serverSock.close();
		} else if(protocolName.equalsIgnoreCase("sr")){
			HashMap<Integer, DataPacket> hashPacket = new HashMap<Integer, DataPacket>();
		
			byte[] byteReceived = new byte[16 + 1 + 4 + segSize];
			BufferedWriter bufferedOutput = new BufferedWriter(new FileWriter("output.txt"));

			boolean lastSeg = false;

			int waitTime = 0;

			Queue<Integer> win = new ArrayDeque<>();

			for(int i = 0; i < N; i++){
				win.add(i);
			}

			while(!lastSeg)
			{

				// Receive Packet
				DatagramPacket packetReceived = new DatagramPacket(byteReceived, byteReceived.length);
				serverSock.receive(packetReceived);
				byte[] receivedDataByte = packetReceived.getData();

				// Making the packet using Java's DataPacket class
				DataPacket packetContent = new DataPacket(receivedDataByte, packetReceived.getLength());

				if (packetContent.packetValidity()) {
		
					System.out.println("This is the sequence number of received packet " + packetContent.getSeqNo()+"....");

					ArrayList<Integer> winlist = new ArrayList<Integer>(win);

					int seqNum = waitTime + winlist.indexOf(packetContent.getSeqNo());

					if(!hashPacket.containsKey(seqNum)){
						hashPacket.put(seqNum, packetContent);

						if (waitTime != seqNum) {
							System.out.println("Out of Order Segment Received.... Expecting the packet with this sequence number" + waitTime % prevSeqNum);
						}
					} else{
						System.out.println("This is duplicate packet with sequence number " + packetContent.getSeqNo() + ": Hence discarding it now.... Please send the expected packets ASAP.");
					}
					
					while(hashPacket.containsKey(waitTime)){
						DataPacket packetWaitTime = hashPacket.get(waitTime);
						lastSeg = packetWaitTime.getLast();
						String packetString = new String(packetWaitTime.getData());
						bufferedOutput.write(packetString);
						System.out.println("This packet has been devlivered successfully.. " + waitTime % prevSeqNum);
						win.add((waitTime + N) % prevSeqNum);
						waitTime++;
						win.remove();
					}

					// Creating ACK Packet with the sequence number
					AcknowledgementDTO ackedData = new AcknowledgementDTO(packetContent.getSeqNo());
					byte[] bytePacket = ackedData.generatePacket();

					Thread.sleep(200);

					DatagramPacket sendACK = new DatagramPacket(bytePacket, bytePacket.length, packetReceived.getAddress(), packetReceived.getPort());

					if (Math.random() > probOfLostACK) {
						serverSock.send(sendACK);
					} else{
						System.out.println("Something went wrong or lost");
					}

					System.out.println("ACK Sent: " + ackedData.getSeqNo());
					
				} else{
					System.out.println("This Packet has been Discarded " + packetContent.getSeqNo() + "; Checksum Error..!");
				}

			}

			bufferedOutput.flush();
			bufferedOutput.close();

			serverSock.close();
		} else{
			serverSock.close();
		}

		
		
	}
}

