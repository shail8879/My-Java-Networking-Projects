import java.nio.ByteBuffer;

public class AcknowledgementDTO{
	
	private int sequenceNumber;

	public AcknowledgementDTO(int seqNo) {
		this.sequenceNumber = seqNo;
	}

	public AcknowledgementDTO(byte[] packet) {
		ByteBuffer buffer = ByteBuffer.wrap(packet);
		this.sequenceNumber = buffer.getInt();
	}

	public int getSeqNo() {
		return sequenceNumber;
	}

	public void setSeqNo(int sequenceNo) {
		this.sequenceNumber = sequenceNo;
	}

	public byte[] generatePacket(){

		byte[] pack = ByteBuffer.allocate(4).putInt(this.sequenceNumber).array();

		return pack;
	}

	
}
