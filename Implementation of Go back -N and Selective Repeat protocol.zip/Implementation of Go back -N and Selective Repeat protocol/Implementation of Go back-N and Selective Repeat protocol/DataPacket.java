import java.util.Arrays;
import java.nio.ByteBuffer;


public class DataPacket {
	private String checksum;
	private int sequenceNum;
	private double bitError = 0.1;
	private boolean lastByte;
	private byte[] dataByte;
	
	public DataPacket(byte[] dataByte,int sequenceNum, boolean lastByte) {
		this.dataByte = dataByte;
		this.sequenceNum = sequenceNum;
		this.lastByte = lastByte;
	}

	public DataPacket(byte[] data, int length) {
		this.checksum = new String(Arrays.copyOfRange(data, 0, 16));

		this.lastByte = Integer.valueOf(data[16]) == 1 ? true : false;

		byte[] dataSeq = Arrays.copyOfRange(data, 17, 21);
		ByteBuffer wrapper = ByteBuffer.wrap(dataSeq);
		this.dataByte = Arrays.copyOfRange(data, 21, length);
        this.sequenceNum = wrapper.getInt();
    }

	public int getSeqNo() {
		return sequenceNum;
	}

	public void setSeqNo(int seqNum) {
		this.sequenceNum = seqNum;
	}

	public byte[] getData() {
		return dataByte;
	}

	public void setData(byte[] data) {
		this.dataByte = data;
	}

	public boolean getLast() {
		return lastByte;
	}

	public void setLast(boolean lastByte) {
		this.lastByte = lastByte;
	}

	public String complement(String num){
		String invertNum = "";

		for(int i = 0; i < num.length(); i++){
			if (num.charAt(i) == '0') {
				invertNum += "1";
			} else{
				invertNum += "0";
			}
		}

		return invertNum;
	}

	public String addition(String a, String b){
		int value1 = Integer.parseInt(a, 2);
		int value2 = Integer.parseInt(b, 2);

		int total = value1 + value2;

		String output = Integer.toString(total, 2);

		while(output.length() > 16 && output.charAt(0) == '1'){
			value1 = Integer.parseInt(output.substring(1), 2);
			value2 = Integer.parseInt(output.substring(0, 1), 2);

			total = value1 + value2;

			output = Integer.toString(total, 2);
		}

		return output;
	}

	public String checksumString(byte[] checkData){

		String[] stringData = new String[checkData.length / 2];

		for(int i = 0; i < checkData.length; i += 2){
			if (i + 1 >= checkData.length) {
				break;
			}

			int content = ((checkData[i] & 0xff) << 8) + (checkData[i + 1] & 0xff);

			stringData[i / 2] = Integer.toString(content, 2);
		}

		String invertedSum = stringData[0];

		for(int j = 1; j < stringData.length; j++){
			invertedSum = addition(invertedSum, stringData[j]);
		}

		if (invertedSum.length() < 16) {
			int length = invertedSum.length();
			for(int i = 0; i < 16 - length; i++){
				invertedSum = "0" + invertedSum;
			}
		}

		String checksum = complement(invertedSum);

		return checksum;
	}

	public byte[] hashData(){
		byte[] seqNum = ByteBuffer.allocate(4).putInt(this.sequenceNum).array();
		byte lastByte = (byte) (this.lastByte ? 1 : 0);

		byte[] hashedString = new byte[1 + seqNum.length + this.dataByte.length];

		hashedString[0] = lastByte;

		System.arraycopy(seqNum, 0, hashedString, 1, seqNum.length);
		System.arraycopy(this.dataByte, 0, hashedString, seqNum.length + 1, this.dataByte.length);

		return hashedString;
	}

	public byte[] packetChecksum(){

		byte[] hashByte = hashData();

		checksum = checksumString(hashByte);

		if (Math.random() <= bitError) {
			checksumError();
		}

		byte[] checksumData = checksum.getBytes();

		byte[] packet = new byte[16 + hashByte.length];

		System.arraycopy(checksumData, 0, packet, 0, checksumData.length);
		System.arraycopy(hashByte, 0, packet, checksumData.length, hashByte.length);

		return packet;
	}

	public void checksumError(){
		if (this.checksum.charAt(0) == '0') {
			this.checksum = "1" + this.checksum.substring(1);
		} else{
			this.checksum = "0" + this.checksum.substring(1);
		}
	}

	public boolean packetValidity(){
		byte[] hashData = hashData();

		String checksumValue = checksumString(hashData);

		return this.checksum.equals(checksumValue);
	}

	
	
}
