import java.io.*;
import java.net.*;
import java.util.*;

public class Sender
{

	// File thats transfered as packets
	public static String fileToBeSent = "ContentToBeSent.txt";

	// Packet Loss Probability
	public static double probOfLostPacket = 0.1;

	public static void main(String args[]) throws Exception
	{
		if (args.length != 3) {
            System.out.println("Invalid input format..!");
            return;
        }

        String protocolFormatFile = args[0];

        int ReceiverPortNo;

		try{
			ReceiverPortNo = Integer.parseInt(args[1]);
		} catch(NumberFormatException e){
			System.out.println("Invalid Port Number.please give integer value ranging from 5000 to 9999..!");
			return;
		}

		int numOfPackets;

		try{
			numOfPackets = Integer.parseInt(args[2]);
		} catch(NumberFormatException e){
			System.out.println("Please specify a valid input for number of packets..!");
			return;
		}

		BufferedReader fileNameRead = new BufferedReader(new FileReader(protocolFormatFile));
		List<String> numOfLinesInAfile = new ArrayList<String>();

		String currentLine;

		while((currentLine = fileNameRead.readLine()) != null) {
		    numOfLinesInAfile.add(currentLine.trim());
		}

		fileNameRead.close();

		String protocolName = numOfLinesInAfile.get(0);

		int m = Integer.parseInt(numOfLinesInAfile.get(1).split(" ")[0].trim());// where m = number of bits in a sequence number.
		int N = Integer.parseInt(numOfLinesInAfile.get(1).split(" ")[1].trim());// where N = window Size.
		int timeOut = Integer.parseInt(numOfLinesInAfile.get(2)) / 1000;
		int segSize = Integer.parseInt(numOfLinesInAfile.get(3)); // where segSize = MSS


		// Creating a Socket
		DatagramSocket senderSoc = new DatagramSocket();
		InetAddress ipAddOfReceiver = InetAddress.getByName("localhost");


		// Send protocol details from input file to Receiver
		String senderData = protocolName + "," + m + "," + N + "," + segSize;
		byte[] inputByte = senderData.getBytes();

		DatagramPacket packet = new DatagramPacket(inputByte, inputByte.length, ipAddOfReceiver, ReceiverPortNo);
		senderSoc.send(packet);


		// Reading Data from the file.
		File fileName = new File(fileToBeSent);
		FileInputStream fileContent = new FileInputStream(fileName);
		byte[] content = new byte[(int) fileName.length()];
		fileContent.read(content);
		fileContent.close();
		int finalSeqNum = (int) (Math.pow(2.0, (double) m));
		int sizeOfTheFile = content.length;
		
		System.out.println("Protocol : " + protocolName);		

		System.out.println("");

		if (protocolName.equalsIgnoreCase("gbn")) {
			int ackReceived = 0;
			int prevPacNum = sizeOfTheFile / segSize;
			int cumulativePacket = 0;
			long timer = System.currentTimeMillis();
			boolean lastLine = false;

			Queue<Integer> win_size = new ArrayDeque<>();

			for(int i = 0; i < N; i++){
				win_size.add(i);
			}

			while (ackReceived <= prevPacNum) {

				while(cumulativePacket - ackReceived < N && !lastLine){
					timer = System.currentTimeMillis();
					int initialByte = cumulativePacket * segSize;
					int finalByte = (cumulativePacket + 1) * segSize;

					if (finalByte > sizeOfTheFile) {
						System.out.println("End..!");
						lastLine = true;
					}

					byte[] byteContent = Arrays.copyOfRange(content, cumulativePacket * segSize, finalByte > sizeOfTheFile ? sizeOfTheFile : finalByte);

					int seqNum = cumulativePacket % finalSeqNum;

					DataPacket packetContent = new DataPacket(byteContent, seqNum, lastLine);

					byte[] dataTransmit = packetContent.packetChecksum();

					DatagramPacket packetTransmit = new DatagramPacket(dataTransmit, dataTransmit.length, ipAddOfReceiver, ReceiverPortNo);

					if (Math.random() > probOfLostPacket) {
						senderSoc.send(packetTransmit);
					} else{
						System.out.print("Lost Packet num: " + seqNum + "; ");
					}

					System.out.println("Sending Packets with sequence number" + seqNum + "; Packet Size: " + dataTransmit.length);
					cumulativePacket++;
				}


				byte[] dataReception = new byte[4];
				DatagramPacket packetReceived = new DatagramPacket(dataReception, dataReception.length);

				try{
					long packetTimer = timeOut - (System.currentTimeMillis() - timer);

					if (packetTimer < 0) {
						throw new SocketTimeoutException();
					}

					senderSoc.setSoTimeout((int) packetTimer);

					senderSoc.receive(packetReceived);

					AcknowledgementDTO ackData = new AcknowledgementDTO(packetReceived.getData());
					Thread.sleep(200);
					System.out.println("");
					System.out.println("Received ACK num: " + ackData.getSeqNo());

					if (win_size.contains(ackData.getSeqNo())){
						while(ackData.getSeqNo() != win_size.poll()){
							timer = System.currentTimeMillis();
							win_size.add((ackReceived + N) % finalSeqNum);
							ackReceived++;
						}
						win_size.add((ackReceived + N) % finalSeqNum);
						ackReceived++;
					}
				} catch(SocketTimeoutException e){

					String contentData = "Timer has expired for Packet : " + ackReceived % finalSeqNum;

					for(int i = ackReceived; i < cumulativePacket; i++){

						int seqNum = i % finalSeqNum;

						contentData += (" Resending the packet with Sequence Num :  " + seqNum +"\n");

						int initialByte = i * segSize;
						int lastByte = (i + 1) * segSize;

						byte[] initialData = Arrays.copyOfRange(content, initialByte, lastByte > sizeOfTheFile ? sizeOfTheFile : lastByte);

						DataPacket packetToBeSent = new DataPacket(initialData, seqNum, lastByte > sizeOfTheFile);

						byte[] transferData = packetToBeSent.packetChecksum();

						DatagramPacket transferPacket = new DatagramPacket(transferData, transferData.length, ipAddOfReceiver, ReceiverPortNo);

						if (Math.random() > probOfLostPacket) {
							senderSoc.send(transferPacket);
						}else{
							System.out.println("sequence num of the lost packet : " + seqNum);
						}
					}

					timer = System.currentTimeMillis();

					contentData += " Timer has started...";

					System.out.println(contentData);
					System.out.println("");
				}
				
			}

			senderSoc.close();
		} else if(protocolName.equalsIgnoreCase("sr")){
			HashMap<Integer, Long> timerOfPacket = new HashMap<Integer, Long>();

			HashMap<Integer, AcknowledgementDTO> ackReceived = new HashMap<Integer, AcknowledgementDTO>();
			int cumulativePacket = 0;
			int ackRecieved = 0;
			boolean lastLine = false;
			int prevPacketNum = sizeOfTheFile / segSize;
			Queue<Integer> win_size = new ArrayDeque<>();

			for(int i = 0; i < N; i++){
				win_size.add(i);
			}

			while (ackRecieved <= prevPacketNum) {

				while(cumulativePacket - ackRecieved < N && !lastLine){

					timerOfPacket.put(cumulativePacket, System.currentTimeMillis());

					int initialByte = cumulativePacket * segSize;
					int finalByte = (cumulativePacket + 1) * segSize;

					if (finalByte > sizeOfTheFile) {
						System.out.println("End..!");
						lastLine = true;
					}

					byte[] byteContent = Arrays.copyOfRange(content, cumulativePacket * segSize, finalByte > sizeOfTheFile ? sizeOfTheFile : finalByte);

					DataPacket packetContent = new DataPacket(byteContent, cumulativePacket % finalSeqNum, lastLine);

					byte[] dataTransmit = packetContent.packetChecksum();

					DatagramPacket packetTransmit = new DatagramPacket(dataTransmit, dataTransmit.length, ipAddOfReceiver, ReceiverPortNo);

					if (Math.random() > probOfLostPacket) {
						senderSoc.send(packetTransmit);
					} else{
						System.out.println(cumulativePacket % finalSeqNum+" this packet is lost now");
					}

					System.out.println("Sending " + cumulativePacket % finalSeqNum + ".... Packet Length: " + dataTransmit.length);

					cumulativePacket++;
				}


				byte[] dataReception = new byte[10];
				DatagramPacket packetReceived = new DatagramPacket(dataReception, dataReception.length);

				try{
					long packetTimer = timeOut - (System.currentTimeMillis() - timerOfPacket.get(ackRecieved));

					if (packetTimer < 0) {
						throw new SocketTimeoutException();
					}

					senderSoc.setSoTimeout((int) packetTimer);

					senderSoc.receive(packetReceived);

					AcknowledgementDTO ackData = new AcknowledgementDTO(packetReceived.getData());

					System.out.println("Received ACK num : " + ackData.getSeqNo());

					ArrayList<Integer> list = new ArrayList<Integer>(win_size);

					int seqNo = ackRecieved + list.indexOf(ackData.getSeqNo());

					ackReceived.put(seqNo, ackData);

					Thread.sleep(200);

					while(ackReceived.containsKey(ackRecieved)){
						win_size.add((ackRecieved + N) % finalSeqNum);
						ackRecieved++;
						win_size.remove();
					}

					System.out.println("");
				} catch(SocketTimeoutException e){

					System.out.println("Packet " + ackRecieved % finalSeqNum + ": Timer expired..! " + ackRecieved % finalSeqNum);

					int initialByte = ackRecieved * segSize;
					int lastByte = (ackRecieved + 1) * segSize;

					byte[] byteContent = Arrays.copyOfRange(content, initialByte, lastByte > sizeOfTheFile ? sizeOfTheFile : lastByte);

					DataPacket packetContent = new DataPacket(byteContent, ackRecieved % finalSeqNum, lastByte > sizeOfTheFile);

					byte[] dataTransmit = packetContent.packetChecksum();

					DatagramPacket transferPacket = new DatagramPacket(dataTransmit, dataTransmit.length, ipAddOfReceiver, ReceiverPortNo);

					if (Math.random() > probOfLostPacket) {
						senderSoc.send(transferPacket);
					}else{
						System.out.println("Lost Packet is " + ackRecieved % finalSeqNum);
					}

					timerOfPacket.put(ackRecieved, System.currentTimeMillis());

					System.out.println("Timer has restarted");
				}
				
			}

			senderSoc.close();
		} else{
			senderSoc.close();
		}
	}
}
