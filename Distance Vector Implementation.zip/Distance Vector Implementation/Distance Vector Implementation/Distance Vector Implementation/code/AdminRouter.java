import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;

public class AdminRouter {
	

	public static void main(String[] args) {
		HashSet<Integer> uniquePortValues = new HashSet<>();
		if (args.length == 0) {
			System.out.println("Please give a valid path to data files directory. Note when you copy file path give / instead of backward slash");
			return;
		} else if (args.length > 1) {
			System.out.println("Incorrect Input Format. Just give directory of data files.");
			return;
		}

		String Directory_path = args[0];
		File file_directory = new File(Directory_path);
		File data_files[] = file_directory.listFiles();
		int size_of_DataFIles = data_files.length;
		if (!file_directory.isDirectory()) {
			System.out.println("Directoy Path is improper");
			return;
		}
		
		int[] input_ports = new int[size_of_DataFIles];
		String nodes = "";
		Scanner readFromDataFiles = new Scanner(System.in);

		for (int i = 0; i < size_of_DataFIles; i++) {
			String temp_values = data_files[i].getName();
			temp_values = temp_values.substring(0, temp_values.indexOf(".dat"));
			System.out.println("Give a valid UDP port for Router: " + temp_values);

			boolean status = true;

			while (status) {
				try {
					 int num = Integer.parseInt(readFromDataFiles.nextLine());

					 if (num <= 1024 || num >= 65536) {
							throw new NumberFormatException();
						}
						if (uniquePortValues.contains(num)) {
							throw new Exception();
						}
						input_ports[i] = num;
						uniquePortValues.add(num);
						status = false;
					} catch (NumberFormatException e) {
						System.out.println("Please enter a port number between the range 1024 and 65536");
						status = true;
					} catch (Exception e) {
						System.out.println("This port is already used. Try giving new port number that is not used so far");
						status = true;
					}
			}
			nodes += " " + temp_values + ":" + input_ports[i];
		}

		readFromDataFiles.close();

		for (int i = 0; i < size_of_DataFIles; i++) {
			ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", "start java Router " + (i + 1) + " \""
					+ data_files[i].getParent().replace("\\", "/") + "\" " + size_of_DataFIles + nodes);
			try {
				processBuilder.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Simulation started");

	}

}
