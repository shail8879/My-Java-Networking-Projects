import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Arrays;

class RouterSimulation extends Thread {

	private String vector;
	private int port;
	private String type;

	public RouterSimulation(String type, String vector, int port) {
		this.type = type;
		this.vector = vector;
		this.port = port;
	}

	public RouterSimulation(String type) {
		this.type = type;
	}

	public void run() {

		if (type.equalsIgnoreCase("r")) {
			Router.readingData();

		} else if (type.equalsIgnoreCase("w")) {

			while (true) {
				try {

					Router.read();
					Router.displayPossibleRoutes();
					Router.broadCastingChangesInValues();

					Thread.sleep(15000);

					Router.distanceVectorAlgorithm();

					Thread.sleep(10000);

				} catch (Exception e) {
				}
			}
		} else if (type.equalsIgnoreCase("u")) {

			Router.updateNetworkValues(vector.split(":"), port);
		}
	}
}

public class Router {

	public static File router_File;
	public static int displayCount = 1;
	public static double[][] router_NetVectors;
	public static int[] Ports;
	public static String[] Nodes;
	public static int routerId;
	public static double[] listOfVectors;
	public static String[] listOfHops;
	public static DatagramSocket dataGramSocket;
	public static String[] listOfNeighbours;

	public static void initializeAllParameters(int length, String[] args, int id, String parent) {

		router_NetVectors = new double[length][length];
		Ports = new int[length];
		Nodes = new String[length];

		for (int i = 0; i < length; i++) {
			Arrays.fill(router_NetVectors[i], Double.MAX_VALUE);
			router_NetVectors[i][i] = 0.0;
			String[] temp = args[i + 3].split(":");
			Nodes[i] = temp[0];
			Ports[i] = Integer.parseInt(temp[1]);
		}

		routerId = id;
		listOfVectors = new double[length];
		listOfHops = new String[length];
		Arrays.fill(listOfVectors, Double.MAX_VALUE);
		listOfVectors[routerId - 1] = 0.0;
		router_File = new File(parent + "/" + Nodes[routerId - 1] + ".dat");
		try {
			dataGramSocket = new DatagramSocket(Ports[routerId - 1]);
		} catch (SocketException e) {

			e.printStackTrace();
		}
		System.out.println("Router with ID" + Nodes[routerId - 1] + " is Working..!");

	}
	
	
	public static void distanceVectorAlgorithm() {
		
		
		for (int i = 0; i < listOfNeighbours.length; i++) {
			int ind = FindingIndex(listOfNeighbours[i]);
			for (int j = 0; j < listOfVectors.length; j++) {
				if (j == routerId - 1) {
					continue;
				} else if (i == 0) {

					listOfVectors[j] = router_NetVectors[routerId - 1][ind] + router_NetVectors[ind][j];
					listOfHops[j] = listOfNeighbours[i];
				} else {

					if (listOfVectors[j] > router_NetVectors[routerId - 1][ind] + router_NetVectors[ind][j]) {
						listOfHops[j] = listOfNeighbours[i];
						listOfVectors[j] = router_NetVectors[routerId - 1][ind] + router_NetVectors[ind][j];
					}

				}
			}
		}
		
		
	}


	public synchronized static void updateNetworkValues(String[] vector, int port) {
		
		int index = 0;
		int ports_Length=Ports.length;
		while(index < ports_Length)
		{
			if (Ports[index] == port)
			{
				break;
			}
			index++;
		}
		if (index == ports_Length)
		{
			return;
		}
		for (int i = 0; i < vector.length; i++)
		{
			router_NetVectors[index][i] = Double.parseDouble(vector[i]);
		}
	}

	public static void broadCastingChangesInValues() {

		try {
			for (int i = 0; i < listOfNeighbours.length; i++) {
				String data = "";
				for (int j = 0; j < listOfVectors.length; j++) {
					if (listOfNeighbours[i].equals(listOfHops[j])) {
						data = data + Double.MAX_VALUE + ":";
					} else {
						data += listOfVectors[j] + ":";
					}
				}
				DatagramPacket datagramPacket = new DatagramPacket(data.getBytes(), data.getBytes().length);
				datagramPacket.setAddress(InetAddress.getByName("localhost"));
				datagramPacket.setPort(Ports[FindingIndex(listOfNeighbours[i])]);
				dataGramSocket.send(datagramPacket);

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void displayPossibleRoutes() {

		System.out.println("> output number " + displayCount++);
		System.out.println();
		String src = Nodes[routerId - 1];
		for (int i = 0; i < listOfVectors.length; i++) {
			if (i != (routerId - 1)) {
				String dest = Nodes[i];
				if (listOfVectors[i] == Double.MAX_VALUE) {
					System.out.println("shortest path from " + src + " to " + dest + ": " + "is not found");
				} else {
					System.out.println("shortest path is " + src + "-" + dest + " : and the next hop is " + listOfHops[i]
							+ " and the cost is " + listOfVectors[i]);
				}
			}
		}

	}

	public static void readingData() {
		
		while (true) {
			try {
				String type = "u";
				byte[] data = new byte[1024];
				int size = data.length;
				DatagramPacket packet = new DatagramPacket(data, size);
				dataGramSocket.receive(packet);
				int length = packet.getLength();
				String vector = new String(packet.getData(), 0, length);
				RouterSimulation updateThread = new RouterSimulation(type, vector, packet.getPort());
				updateThread.start();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String args[]) {
		initializeAllParameters(Integer.parseInt(args[2]), args, Integer.parseInt(args[0]), args[1]);

		RouterSimulation readThread = new RouterSimulation("r");
		readThread.start();

		RouterSimulation writeThread = new RouterSimulation("w");
		writeThread.start();

		while (true);
	}

	public static void read() {
		try {
			Arrays.fill(router_NetVectors[routerId - 1], Double.MAX_VALUE);
			router_NetVectors[routerId - 1][routerId - 1] = 0.0;
			BufferedReader bufferReader = new BufferedReader(new FileReader(router_File));
			int length = Integer.parseInt(bufferReader.readLine());
			listOfNeighbours = new String[length];
			for (int i = 0; i < length; i++) {

				String[] temp = bufferReader.readLine().split(" ");
				int index = FindingIndex(temp[0]);
				listOfNeighbours[i] = temp[0];

				if (displayCount == 1) {
					listOfHops[index] = temp[0];
					listOfVectors[index] = Double.parseDouble(temp[1]);
				} else {

				}
				router_NetVectors[routerId - 1][index] = Double.parseDouble(temp[1]);

			}
			bufferReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static int FindingIndex(String temp) {
		int position = -1;
		for (int i = 0; i < Nodes.length; i++) {
			if (Nodes[i].equals(temp)) {
				position = i;
				break;
			}
		}
		return position;
	}
	
}

